# Oto Tıklayıcı

Kaydet - oynat tarzı otomatik tıklayıcı (Erişilebilirlik hizmeti ile).
- Yüzen panel: ⏺ kaydet, ■ bitir, ▶ oynat
- Dokunma, kaydırma ve basılı tutma kaydedilir; kayıtlar saklanır
- Tekrar sayısı, hız, bekleme, geri sayım ayarları
- İnternet ve izin yok, veri toplamaz
