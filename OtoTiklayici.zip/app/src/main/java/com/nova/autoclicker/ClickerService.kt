package com.nova.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.hypot

/** Tam ekran şeffaf katman: kayıt sırasında dokunuşları yakalar, oynatmada dokunma halkalarını gösterir. */
class TouchOverlay(ctx: Context, private val interactive: Boolean) : View(ctx) {

    private class Mark(val x: Float, val y: Float, val n: Int)
    private class Flash(val x: Float, val y: Float, val t0: Long)

    var onTouch: ((MotionEvent) -> Unit)? = null

    private val marks = ArrayList<Mark>()
    private val flashes = ArrayList<Flash>()
    private val trail = Path()
    private var tx = 0f
    private var ty = 0f
    private var down = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density

    fun addMark(x: Float, y: Float, n: Int) {
        marks.add(Mark(x, y, n))
        if (marks.size > 40) marks.removeAt(0)
        postInvalidate()
    }

    fun flash(x: Float, y: Float) {
        flashes.add(Flash(x, y, SystemClock.uptimeMillis()))
        postInvalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!interactive) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                down = true
                tx = e.rawX
                ty = e.rawY
                trail.reset()
                trail.moveTo(tx, ty)
            }
            MotionEvent.ACTION_MOVE -> {
                tx = e.rawX
                ty = e.rawY
                trail.lineTo(tx, ty)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> down = false
        }
        invalidate()
        onTouch?.invoke(e)
        return true
    }

    override fun onDraw(c: Canvas) {
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        c.save()
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())

        if (interactive) {
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(14, 255, 59, 48)
            c.drawRect(loc[0].toFloat(), loc[1].toFloat(), (loc[0] + width).toFloat(), (loc[1] + height).toFloat(), paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f * d
            paint.color = Color.argb(200, 255, 59, 48)
            c.drawRect(
                loc[0] + 1.5f * d, loc[1] + 1.5f * d,
                (loc[0] + width) - 1.5f * d, (loc[1] + height) - 1.5f * d, paint
            )
        }

        paint.textAlign = Paint.Align.CENTER
        for (m in marks) {
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(210, 255, 59, 48)
            c.drawCircle(m.x, m.y, 13f * d, paint)
            paint.color = Color.WHITE
            paint.textSize = 12f * d
            c.drawText(m.n.toString(), m.x, m.y + 4.5f * d, paint)
        }

        if (down) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 4f * d
            paint.color = Color.argb(200, 255, 255, 255)
            c.drawPath(trail, paint)
            paint.color = Color.argb(230, 59, 130, 246)
            c.drawCircle(tx, ty, 26f * d, paint)
        }

        val now = SystemClock.uptimeMillis()
        val it = flashes.iterator()
        var active = false
        while (it.hasNext()) {
            val f = it.next()
            val age = now - f.t0
            if (age > 450) {
                it.remove()
            } else {
                active = true
                val k = age / 450f
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 4f * d
                paint.color = Color.argb((255 * (1f - k)).toInt(), 59, 130, 246)
                c.drawCircle(f.x, f.y, (12f + 30f * k) * d, paint)
            }
        }
        c.restore()
        if (active) postInvalidateOnAnimation()
    }
}

class ClickerService : AccessibilityService() {

    companion object {
        var instance: ClickerService? = null
    }

    enum class State { IDLE, COUNTDOWN, RECORDING, PLAYING }

    lateinit var store: Store
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    var state = State.IDLE
        private set

    private var panelView: LinearLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var statusTv: TextView? = null
    private var overlay: TouchOverlay? = null
    private var overlayLp: WindowManager.LayoutParams? = null
    private var runId = 0

    // kayıt
    private val recGestures = ArrayList<Gesture>()
    private var recStart = 0L
    private var lastEnd = 0L
    private var curPts: ArrayList<Pt>? = null
    private var curT0 = 0L
    private var curGap = 0L

    // oynatma
    private var playRec: Recording? = null
    private var loopIndex = 0
    private var curStep = 0
    private var fails = 0
    private var countdownLeft = 0
    private var playLoops = 1
    private var playSpeed = 1f
    private var scaleX = 1f
    private var scaleY = 1f

    // ---------------------------------------------------------------- yaşam döngüsü

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        store = Store(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        stopAll()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        handler.removeCallbacksAndMessages(null)
        runId++
        state = State.IDLE
        removeOverlay()
        val p = panelView
        if (p != null) {
            try {
                wm.removeView(p)
            } catch (e: Exception) {
            }
        }
        panelView = null
        panelLp = null
        instance = null
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!::store.isInitialized || !store.volStop) return false
        if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && state != State.IDLE) {
            if (event.action == KeyEvent.ACTION_DOWN) handler.post { stopAll() }
            return true
        }
        return false
    }

    // ---------------------------------------------------------------- yardımcılar

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    @Suppress("DEPRECATION")
    private fun realSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return Pair(dm.widthPixels, dm.heightPixels)
    }

    private fun setFlag(v: View?, lp: WindowManager.LayoutParams?, flag: Int, on: Boolean) {
        if (v == null || lp == null) return
        lp.flags = if (on) lp.flags or flag else lp.flags and flag.inv()
        try {
            wm.updateViewLayout(v, lp)
        } catch (e: Exception) {
        }
    }

    private fun setPanelTouchable(touchable: Boolean) {
        setFlag(panelView, panelLp, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, !touchable)
    }

    private fun setOverlayTouchable(touchable: Boolean) {
        setFlag(overlay, overlayLp, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, !touchable)
    }

    // ---------------------------------------------------------------- yüzen panel

    fun showPanel() {
        if (panelView != null) {
            renderPanel()
            return
        }
        val v = LinearLayout(this)
        v.orientation = LinearLayout.HORIZONTAL
        v.gravity = Gravity.CENTER_VERTICAL
        val bg = GradientDrawable()
        bg.setColor(Color.argb(238, 28, 29, 33))
        bg.cornerRadius = dp(26).toFloat()
        bg.setStroke(dp(1), Color.argb(70, 255, 255, 255))
        v.background = bg
        v.setPadding(dp(8), dp(6), dp(8), dp(6))

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = if (store.panelX >= 0) store.panelX else dp(12)
        lp.y = if (store.panelY >= 0) store.panelY else dp(140)
        panelView = v
        panelLp = lp
        try {
            wm.addView(v, lp)
        } catch (e: Exception) {
            panelView = null
            panelLp = null
            return
        }
        renderPanel()
    }

    fun hidePanel() {
        stopAll()
        val p = panelView
        if (p != null) {
            try {
                wm.removeView(p)
            } catch (e: Exception) {
            }
        }
        panelView = null
        panelLp = null
        statusTv = null
    }

    private fun bringPanelToFront() {
        val p = panelView ?: return
        val lp = panelLp ?: return
        try {
            wm.removeView(p)
            wm.addView(p, lp)
        } catch (e: Exception) {
        }
    }

    private fun dragHandle(): TextView {
        val h = TextView(this)
        h.text = "⋮⋮"
        h.textSize = 18f
        h.setTextColor(Color.argb(190, 255, 255, 255))
        h.setPadding(dp(6), dp(4), dp(10), dp(4))
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        h.setOnTouchListener { _, e ->
            val lp = panelLp
            val v = panelView
            if (lp != null && v != null) {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX
                        sy = e.rawY
                        ox = lp.x
                        oy = lp.y
                    }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = ox + (e.rawX - sx).toInt()
                        lp.y = oy + (e.rawY - sy).toInt()
                        try {
                            wm.updateViewLayout(v, lp)
                        } catch (ex: Exception) {
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        store.panelX = lp.x
                        store.panelY = lp.y
                    }
                }
            }
            true
        }
        return h
    }

    private fun pbtn(label: String, color: Int, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = label
        b.textSize = 15f
        b.setTextColor(Color.WHITE)
        b.setTypeface(b.typeface, Typeface.BOLD)
        b.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.setColor(color)
        bg.cornerRadius = dp(20).toFloat()
        b.background = bg
        b.setPadding(dp(14), dp(8), dp(14), dp(8))
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.leftMargin = dp(3)
        lp.rightMargin = dp(3)
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    private fun statusLabel(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 13f
        t.setTextColor(Color.argb(230, 255, 255, 255))
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.maxWidth = dp(130)
        t.setPadding(dp(6), 0, dp(6), 0)
        statusTv = t
        return t
    }

    private val red = Color.parseColor("#E5484D")
    private val green = Color.parseColor("#2EB67D")
    private val gray = Color.parseColor("#4A4B50")
    private val blue = Color.parseColor("#3B82F6")

    private fun renderPanel() {
        val p = panelView ?: return
        p.removeAllViews()
        statusTv = null
        p.addView(dragHandle())
        when (state) {
            State.IDLE -> {
                p.addView(pbtn("⏺", red) { startRecording() })
                p.addView(pbtn("▶", green) { playSelected() })
                val sel = store.selectedRec()
                val l = statusLabel(sel?.name ?: "Kayıt yok")
                l.setOnClickListener { cycleSelected() }
                p.addView(l)
                p.addView(pbtn("⌂", gray) { openApp() })
                p.addView(pbtn("✕", gray) { hidePanel() })
            }
            State.COUNTDOWN -> {
                p.addView(pbtn("■", red) { stopAll() })
                p.addView(statusLabel("Başlıyor: $countdownLeft…"))
            }
            State.RECORDING -> {
                p.addView(pbtn("■ Bitir", red) { finishRecording() })
                p.addView(statusLabel(""))
                updateRecStatus()
            }
            State.PLAYING -> {
                p.addView(pbtn("■ Durdur", red) { stopAll() })
                p.addView(statusLabel(""))
                updatePlayStatus()
            }
        }
    }

    private fun cycleSelected() {
        val l = store.list()
        if (l.size < 2) return
        val idx = l.indexOfFirst { it.id == store.selected }
        store.selected = l[(idx + 1) % l.size].id
        renderPanel()
    }

    private fun openApp() {
        val i = Intent(this, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        startActivity(i)
    }

    private fun playSelected() {
        val rec = store.selectedRec()
        if (rec == null) {
            toast("Henüz kayıt yok. Önce ⏺ ile kaydet.")
            return
        }
        play(rec)
    }

    // ---------------------------------------------------------------- katman

    private fun addOverlay(interactive: Boolean) {
        removeOverlay()
        val ov = TouchOverlay(this, interactive)
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        if (!interactive) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            wm.addView(ov, lp)
        } catch (e: Exception) {
            return
        }
        overlay = ov
        overlayLp = lp
        bringPanelToFront()
    }

    private fun removeOverlay() {
        val o = overlay
        if (o != null) {
            try {
                wm.removeView(o)
            } catch (e: Exception) {
            }
        }
        overlay = null
        overlayLp = null
    }

    // ---------------------------------------------------------------- kayıt

    fun startRecording() {
        if (state != State.IDLE) return
        showPanel()
        recGestures.clear()
        curPts = null
        recStart = SystemClock.uptimeMillis()
        lastEnd = recStart
        state = State.RECORDING
        addOverlay(true)
        val ov = overlay
        if (ov == null) {
            state = State.IDLE
            toast("Kayıt katmanı açılamadı")
            renderPanel()
            return
        }
        ov.onTouch = { e -> onRecTouch(e) }
        renderPanel()
        handler.postDelayed(recTick, 500L)
    }

    private val recTick = object : Runnable {
        override fun run() {
            if (state == State.RECORDING) {
                updateRecStatus()
                handler.postDelayed(this, 500L)
            }
        }
    }

    private fun updateRecStatus() {
        val s = (SystemClock.uptimeMillis() - recStart) / 1000
        statusTv?.text = String.format(Locale.US, "● %02d:%02d · %d işlem", s / 60, s % 60, recGestures.size)
    }

    private fun onRecTouch(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val list = ArrayList<Pt>()
                list.add(Pt(e.rawX, e.rawY))
                curPts = list
                curT0 = e.eventTime
                var gap = e.eventTime - lastEnd
                if (recGestures.isEmpty()) gap = minOf(gap, 400L)
                curGap = maxOf(gap, 0L)
            }
            MotionEvent.ACTION_MOVE -> {
                curPts?.add(Pt(e.rawX, e.rawY))
            }
            MotionEvent.ACTION_UP -> {
                val pts = curPts
                curPts = null
                if (pts != null) {
                    pts.add(Pt(e.rawX, e.rawY))
                    finishGesture(pts, e.eventTime)
                }
            }
            MotionEvent.ACTION_CANCEL -> curPts = null
        }
    }

    private fun finishGesture(pts: ArrayList<Pt>, endTime: Long) {
        val dur = maxOf(1L, endTime - curT0)
        val p0 = pts[0]
        var maxD = 0f
        for (p in pts) maxD = maxOf(maxD, hypot(p.x - p0.x, p.y - p0.y))
        val g: Gesture = if (maxD < dp(14)) {
            Gesture(curGap, dur.coerceIn(20L, 6000L), listOf(p0))
        } else {
            Gesture(curGap, dur.coerceIn(30L, 20000L), downsample(pts, 40))
        }
        recGestures.add(g)
        lastEnd = endTime
        overlay?.addMark(p0.x, p0.y, recGestures.size)
        updateRecStatus()
        passThrough(g)
    }

    private fun downsample(pts: List<Pt>, maxN: Int): List<Pt> {
        if (pts.size <= maxN) return ArrayList(pts)
        val out = ArrayList<Pt>()
        for (i in 0 until maxN) {
            val idx = (i.toLong() * (pts.size - 1) / (maxN - 1)).toInt()
            out.add(pts[idx])
        }
        return out
    }

    /** Katman dokunuşu yuttuğu için, aynı hareketi alttaki uygulamaya tekrar iletir. */
    private fun passThrough(g: Gesture) {
        setOverlayTouchable(false)
        handler.postDelayed({
            if (state == State.RECORDING) {
                dispatch(g, 1f, 1f, 1f, false) { setOverlayTouchable(true) }
            } else {
                setOverlayTouchable(true)
            }
        }, 40L)
    }

    private fun finishRecording() {
        if (state != State.RECORDING) return
        handler.removeCallbacksAndMessages(null)
        removeOverlay()
        state = State.IDLE
        curPts = null
        if (recGestures.isEmpty()) {
            toast("Hiçbir işlem kaydedilmedi")
            renderPanel()
            return
        }
        val size = realSize()
        val now = System.currentTimeMillis()
        val name = "Kayıt " + SimpleDateFormat("d MMM HH:mm", Locale("tr")).format(Date(now))
        val rec = Recording(now, name, now, size.first, size.second, ArrayList(recGestures))
        store.add(rec)
        store.selected = rec.id
        toast("✓ Kaydedildi: ${rec.gestures.size} işlem")
        recGestures.clear()
        renderPanel()
    }

    // ---------------------------------------------------------------- oynatma

    fun play(rec: Recording) {
        if (state != State.IDLE) return
        if (rec.gestures.isEmpty()) {
            toast("Bu kayıt boş")
            return
        }
        showPanel()
        store.selected = rec.id
        playRec = rec
        playLoops = store.loops
        playSpeed = store.speed
        val size = realSize()
        scaleX = size.first.toFloat() / rec.w
        scaleY = size.second.toFloat() / rec.h
        if ((rec.w > rec.h) != (size.first > size.second)) toast("Dikkat: ekran yönü kayıttan farklı")
        state = State.COUNTDOWN
        runId++
        countdown(store.startDelay)
    }

    private fun countdown(left: Int) {
        if (state != State.COUNTDOWN) return
        val id = runId
        if (left <= 0) {
            beginPlay()
            return
        }
        countdownLeft = left
        renderPanel()
        handler.postDelayed({
            if (id == runId) countdown(left - 1)
        }, 1000L)
    }

    private fun beginPlay() {
        state = State.PLAYING
        loopIndex = 0
        curStep = 0
        fails = 0
        val id = ++runId
        if (store.showTouches) addOverlay(false)
        renderPanel()
        step(id, 0, 200L)
    }

    private fun step(id: Int, i: Int, delay: Long) {
        handler.postDelayed({
            if (id == runId && state == State.PLAYING) doStep(id, i)
        }, delay)
    }

    private fun doStep(id: Int, i: Int) {
        val rec = playRec ?: return
        if (i >= rec.gestures.size) {
            loopDone(id)
            return
        }
        curStep = i
        updatePlayStatus()
        val g = rec.gestures[i]
        dispatch(g, scaleX, scaleY, playSpeed, store.showTouches) { ok ->
            if (id == runId && state == State.PLAYING) {
                if (ok) fails = 0 else fails++
                if (fails >= 5) {
                    toast("Hareketler uygulanamadı, durduruldu")
                    stopAll()
                } else {
                    val nextGap = if (i + 1 < rec.gestures.size) (rec.gestures[i + 1].gapMs / playSpeed).toLong() else 0L
                    step(id, i + 1, nextGap)
                }
            }
        }
    }

    private fun loopDone(id: Int) {
        loopIndex++
        if (playLoops != 0 && loopIndex >= playLoops) {
            toast("Oynatma bitti ✓")
            finishPlayback()
        } else {
            step(id, 0, store.interval.toLong())
        }
    }

    private fun updatePlayStatus() {
        val rec = playRec ?: return
        val loops = if (playLoops == 0) "∞" else playLoops.toString()
        statusTv?.text = "↻ ${loopIndex + 1}/$loops · ${curStep + 1}/${rec.gestures.size}"
    }

    private fun finishPlayback() {
        runId++
        handler.removeCallbacksAndMessages(null)
        removeOverlay()
        setPanelTouchable(true)
        state = State.IDLE
        renderPanel()
    }

    fun stopAll() {
        when (state) {
            State.RECORDING -> finishRecording()
            State.IDLE -> {}
            else -> finishPlayback()
        }
    }

    // ---------------------------------------------------------------- hareket gönderme

    private fun overlapsPanel(g: Gesture, sx: Float, sy: Float): Boolean {
        val v = panelView ?: return false
        if (v.width == 0) return false
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        val m = dp(12)
        val r = Rect(loc[0] - m, loc[1] - m, loc[0] + v.width + m, loc[1] + v.height + m)
        for (p in g.pts) {
            if (r.contains((p.x * sx).toInt(), (p.y * sy).toInt())) return true
        }
        return false
    }

    private fun dispatch(g: Gesture, sx: Float, sy: Float, speed: Float, indicate: Boolean, cb: (Boolean) -> Unit) {
        val size = realSize()
        val path = Path()
        var fx = 0f
        var fy = 0f
        for ((k, p) in g.pts.withIndex()) {
            val x = (p.x * sx).coerceIn(0f, (size.first - 1).toFloat())
            val y = (p.y * sy).coerceIn(0f, (size.second - 1).toFloat())
            if (k == 0) {
                path.moveTo(x, y)
                fx = x
                fy = y
            } else {
                path.lineTo(x, y)
            }
        }
        val minDur = if (g.pts.size == 1) 20L else 30L
        val dur = (g.durMs / speed).toLong().coerceIn(minDur, 20000L)

        val hide = overlapsPanel(g, sx, sy)
        val run = Runnable {
            var ok = false
            try {
                val gd = GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0L, dur))
                    .build()
                ok = dispatchGesture(gd, object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (hide) setPanelTouchable(true)
                        cb(true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (hide) setPanelTouchable(true)
                        cb(false)
                    }
                }, null)
            } catch (e: Exception) {
                ok = false
            }
            if (ok) {
                if (indicate) overlay?.flash(fx, fy)
            } else {
                if (hide) setPanelTouchable(true)
                cb(false)
            }
        }
        if (hide) {
            setPanelTouchable(false)
            handler.postDelayed(run, 40L)
        } else {
            run.run()
        }
    }
}
