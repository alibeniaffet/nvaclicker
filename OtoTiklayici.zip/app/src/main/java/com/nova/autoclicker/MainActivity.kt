package com.nova.autoclicker

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var store: Store
    private var scroll: ScrollView? = null
    private var dark = false
    private var cBg = 0
    private var cCard = 0
    private var cText = 0
    private var cSub = 0
    private val accent = Color.parseColor("#3B82F6")
    private val red = Color.parseColor("#E5484D")
    private val green = Color.parseColor("#2EB67D")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        val night = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK
        dark = night == android.content.res.Configuration.UI_MODE_NIGHT_YES
        cBg = Color.parseColor(if (dark) "#101012" else "#F4F5F7")
        cCard = Color.parseColor(if (dark) "#1C1D21" else "#FFFFFF")
        cText = Color.parseColor(if (dark) "#E8EAED" else "#202124")
        cSub = Color.parseColor(if (dark) "#9AA0A6" else "#5F6368")
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    // ---------------------------------------------------------------- yardımcılar

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int, stroke: Int = 0): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(r).toFloat()
        if (stroke != 0) d.setStroke(dp(2), stroke)
        return d
    }

    private fun text(s: String, size: Float = 15f, color: Int = cText, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun lp(top: Int = 10): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(MP, WC)
        l.topMargin = dp(top)
        return l
    }

    private fun card(stroke: Int = 0): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = rounded(cCard, 16, stroke)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        return c
    }

    private fun button(label: String, color: Int, filled: Boolean, onClick: () -> Unit): TextView {
        val b = text(label, 15f, if (filled) Color.WHITE else color, true)
        b.gravity = Gravity.CENTER
        b.background = if (filled) rounded(color, 12) else rounded(Color.TRANSPARENT, 12, color)
        b.setPadding(dp(14), dp(12), dp(14), dp(12))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun section(s: String): TextView {
        val t = text(s, 13f, accent, true)
        t.setPadding(dp(4), dp(22), 0, dp(2))
        return t
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun serviceEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val id = ComponentName(this, ClickerService::class.java).flattenToString()
        val short = packageName + "/.ClickerService"
        return s.split(':').any { it.equals(id, true) || it.equals(short, true) }
    }

    private fun fmtSec(ms: Long): String = String.format(Locale.US, "%.1f sn", ms / 1000.0)

    private fun loopsLabel(n: Int) = if (n == 0) "Sonsuz" else "$n kez"

    // ---------------------------------------------------------------- arayüz

    private fun render() {
        val oldY = scroll?.scrollY ?: 0
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(20), dp(16), dp(40))

        col.addView(text("🎯 Oto Tıklayıcı", 26f, cText, true))
        col.addView(text("Bir kez kaydet, istediğin kadar aynısını tekrar oynat.", 14f, cSub))

        val on = serviceEnabled() || ClickerService.instance != null

        // Hizmet durumu
        col.addView(section("DURUM"))
        val st = card()
        st.addView(text(if (on) "✅ Erişilebilirlik hizmeti açık" else "❌ Erişilebilirlik hizmeti kapalı", 15f, cText, true))
        if (!on) {
            st.addView(
                text(
                    "Dokunmaları kaydedip oynatabilmek için bu izin gerekli. Ayarlarda “Oto Tıklayıcı”yı bulup aç.\n\n" +
                        "Seçenek gri ve açılmıyorsa: Telefon Ayarları > Uygulamalar > Oto Tıklayıcı > ⋮ (sağ üst) > " +
                        "“Kısıtlanmış ayarlara izin ver”, sonra tekrar dene.",
                    13f, cSub
                ), lp(6)
            )
            st.addView(button("Erişilebilirlik ayarlarını aç", accent, true) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }, lp(10))
        }
        col.addView(st, lp(8))

        // Kayıt başlat
        col.addView(section("KAYDET"))
        val rec = card()
        rec.addView(
            text(
                "1) Aşağıdaki düğmeye bas, yüzen panel açılır.\n" +
                    "2) Hedef uygulamaya git.\n" +
                    "3) Panelde ⏺'a bas ve ekranı normal kullan (dokun, kaydır, basılı tut).\n" +
                    "4) ■ Bitir'e bas. Kayıt otomatik kaydedilir.",
                13f, cText
            )
        )
        rec.addView(button("⏺ Kayıt panelini aç", red, true) {
            val svc = ClickerService.instance
            if (svc == null) {
                toast("Önce erişilebilirlik hizmetini aç")
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                svc.showPanel()
                moveTaskToBack(true)
            }
        }, lp(10))
        col.addView(rec, lp(8))

        // Kayıtlar
        val list = store.list()
        col.addView(section("KAYITLAR (${list.size})"))
        if (list.isEmpty()) {
            val e = card()
            e.addView(text("Henüz kayıt yok. Yukarıdan ilk kaydını yap.", 14f, cSub))
            col.addView(e, lp(8))
        }
        val sel = store.selectedRec()?.id ?: 0L
        val df = SimpleDateFormat("d MMM HH:mm", Locale("tr"))
        for (r in list) {
            val c = card(if (r.id == sel) accent else 0)
            c.addView(text(r.name, 16f, cText, true))
            c.addView(
                text("${r.gestures.size} işlem · ${fmtSec(r.totalMs())} · ${df.format(Date(r.created))}", 12f, cSub)
            )
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val play = button("▶ Oynat", green, true) { playRec(r) }
            val ren = button("✎", accent, false) { renameDialog(r) }
            val del = button("🗑", red, false) { deleteDialog(r) }
            val lpPlay = LinearLayout.LayoutParams(0, WC, 3f)
            val lpSmall = LinearLayout.LayoutParams(0, WC, 1f)
            lpSmall.leftMargin = dp(8)
            row.addView(play, lpPlay)
            row.addView(ren, lpSmall)
            row.addView(del, lpSmall)
            c.addView(row, lp(10))
            col.addView(c, lp(8))
        }

        // Oynatma ayarları
        col.addView(section("OYNATMA AYARLARI"))
        val set = card()
        set.addView(
            choiceRow("Tekrar sayısı", loopsLabel(store.loops)) { loopsDialog() }
        )
        set.addView(
            choiceRow("Hız", speedLabel(store.speed)) { speedDialog() }
        )
        set.addView(
            choiceRow("Tekrarlar arası bekleme", "${store.interval} ms") { intervalDialog() }
        )
        set.addView(
            choiceRow("Başlamadan önce geri sayım", if (store.startDelay == 0) "Hemen" else "${store.startDelay} sn") { delayDialog() }
        )
        set.addView(toggleRow("Dokunmaları göster", "Oynatırken her dokunuşta halka çıkar", store.showTouches) { store.showTouches = it })
        set.addView(toggleRow("Ses kısma tuşuyla durdur", "Kayıt veya oynatma sırasında ses azalt tuşuna bas", store.volStop) { store.volStop = it })
        col.addView(set, lp(8))

        // Notlar
        col.addView(section("BİLMEN GEREKENLER"))
        val notes = card()
        notes.addView(
            text(
                "• Tek parmak dokunma, kaydırma ve basılı tutma kaydedilir. Çoklu dokunma (iki parmak) desteklenmez.\n" +
                    "• Kayıt sırasında dokunuşlar hemen uygulanır; kaydırmalar parmağını kaldırınca gönderilir.\n" +
                    "• Aynı ekran yönünde ve aynı sayfada başlatırsan en doğru sonucu alırsın.\n" +
                    "• Bazı güvenli ekranlar (PIN, bankacılık, izin pencereleri) dışarıdan dokunuşu kabul etmez.\n" +
                    "• Uygulama internet kullanmaz, izin istemez, hiçbir veri toplamaz.",
                13f, cText
            )
        )
        col.addView(notes, lp(8))

        val sv = ScrollView(this)
        sv.setBackgroundColor(cBg)
        sv.isFillViewport = true
        sv.clipToPadding = false
        sv.addView(col, ViewGroup.LayoutParams(MP, WC))
        ViewCompat.setOnApplyWindowInsetsListener(sv) { v, ins ->
            val b = ins.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            ins
        }
        setContentView(sv)
        scroll = sv
        sv.post { sv.scrollTo(0, oldY) }
    }

    private fun choiceRow(title: String, value: String, onClick: () -> Unit): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setPadding(0, dp(9), 0, dp(9))
        r.addView(text(title, 16f))
        r.addView(text(value, 13f, cSub))
        r.setOnClickListener { onClick() }
        return r
    }

    private fun toggleRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(9), 0, dp(9))
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.addView(text(title, 16f))
        c.addView(text(desc, 12f, cSub))
        r.addView(c, LinearLayout.LayoutParams(0, WC, 1f))
        val sw = Switch(this)
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, on -> onChange(on) }
        r.addView(sw)
        return r
    }

    // ---------------------------------------------------------------- eylemler

    private fun playRec(r: Recording) {
        val svc = ClickerService.instance
        if (svc == null) {
            toast("Önce erişilebilirlik hizmetini aç")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        if (svc.state != ClickerService.State.IDLE) {
            toast("Önce çalışanı durdur")
            return
        }
        store.selected = r.id
        svc.play(r)
        moveTaskToBack(true)
    }

    private fun renameDialog(r: Recording) {
        val input = EditText(this)
        input.setText(r.name)
        input.setSingleLine()
        input.selectAll()
        val box = FrameLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(input)
        AlertDialog.Builder(this)
            .setTitle("Kaydı yeniden adlandır")
            .setView(box)
            .setPositiveButton("Kaydet") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty()) {
                    store.rename(r.id, n)
                    render()
                }
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun deleteDialog(r: Recording) {
        AlertDialog.Builder(this)
            .setTitle("Kayıt silinsin mi?")
            .setMessage(r.name)
            .setPositiveButton("Sil") { _, _ ->
                store.delete(r.id)
                render()
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun pick(title: String, labels: List<String>, checked: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(labels.toTypedArray(), checked) { d, w ->
                d.dismiss()
                onPick(w)
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun loopsDialog() {
        val values = listOf(1, 5, 10, 25, 50, 100, 500, 0)
        val labels = values.map { loopsLabel(it) } + "Özel sayı…"
        pick("Tekrar sayısı", labels, values.indexOf(store.loops)) { i ->
            if (i < values.size) {
                store.loops = values[i]
                render()
            } else {
                val input = EditText(this)
                input.inputType = InputType.TYPE_CLASS_NUMBER
                input.hint = "ör. 30"
                val box = FrameLayout(this)
                box.setPadding(dp(20), dp(8), dp(20), 0)
                box.addView(input)
                AlertDialog.Builder(this)
                    .setTitle("Kaç kez tekrarlansın?")
                    .setView(box)
                    .setPositiveButton("Tamam") { _, _ ->
                        val n = input.text.toString().toIntOrNull()
                        if (n != null && n in 1..100000) {
                            store.loops = n
                            render()
                        }
                    }
                    .setNegativeButton("İptal", null)
                    .show()
            }
        }
    }

    private fun speedLabel(s: Float): String = if (s == 1f) "1× (kayıttaki gibi)" else "${s}×"

    private fun speedDialog() {
        val values = listOf(0.5f, 0.75f, 1f, 1.5f, 2f, 3f)
        pick("Hız", values.map { speedLabel(it) }, values.indexOf(store.speed)) { i ->
            store.speed = values[i]
            render()
        }
    }

    private fun intervalDialog() {
        val values = listOf(0, 250, 500, 1000, 2000, 5000, 10000)
        pick("Tekrarlar arası bekleme", values.map { "$it ms" }, values.indexOf(store.interval)) { i ->
            store.interval = values[i]
            render()
        }
    }

    private fun delayDialog() {
        val values = listOf(0, 1, 3, 5, 10)
        pick("Geri sayım", values.map { if (it == 0) "Hemen" else "$it sn" }, values.indexOf(store.startDelay)) { i ->
            store.startDelay = values[i]
            render()
        }
    }
}
