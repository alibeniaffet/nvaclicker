package com.nova.autoclicker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Pt(val x: Float, val y: Float)

/** Tek bir dokunma/kaydırma. gapMs: önceki işlemin bitişinden bu işlemin başlangıcına kadar geçen süre. */
class Gesture(val gapMs: Long, val durMs: Long, val pts: List<Pt>)

class Recording(
    val id: Long,
    var name: String,
    val created: Long,
    val w: Int,
    val h: Int,
    val gestures: List<Gesture>
) {
    fun totalMs(): Long {
        var t = 0L
        for (g in gestures) t += g.gapMs + g.durMs
        return t
    }
}

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("clicker", Context.MODE_PRIVATE)

    // 0 = sonsuz
    var loops: Int
        get() = sp.getInt("loops", 1)
        set(v) {
            sp.edit().putInt("loops", v).apply()
        }

    var speed: Float
        get() = sp.getFloat("speed", 1f)
        set(v) {
            sp.edit().putFloat("speed", v).apply()
        }

    // döngüler arası bekleme (ms)
    var interval: Int
        get() = sp.getInt("interval", 500)
        set(v) {
            sp.edit().putInt("interval", v).apply()
        }

    // oynatmadan önce geri sayım (sn)
    var startDelay: Int
        get() = sp.getInt("start_delay", 3)
        set(v) {
            sp.edit().putInt("start_delay", v).apply()
        }

    var showTouches: Boolean
        get() = sp.getBoolean("show_touches", true)
        set(v) {
            sp.edit().putBoolean("show_touches", v).apply()
        }

    var volStop: Boolean
        get() = sp.getBoolean("vol_stop", true)
        set(v) {
            sp.edit().putBoolean("vol_stop", v).apply()
        }

    var selected: Long
        get() = sp.getLong("selected", 0L)
        set(v) {
            sp.edit().putLong("selected", v).apply()
        }

    var panelX: Int
        get() = sp.getInt("panel_x", -1)
        set(v) {
            sp.edit().putInt("panel_x", v).apply()
        }

    var panelY: Int
        get() = sp.getInt("panel_y", -1)
        set(v) {
            sp.edit().putInt("panel_y", v).apply()
        }

    fun list(): MutableList<Recording> {
        val out = mutableListOf<Recording>()
        try {
            val arr = JSONArray(sp.getString("recs", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val gs = o.getJSONArray("gs")
                val gestures = ArrayList<Gesture>()
                for (j in 0 until gs.length()) {
                    val g = gs.getJSONObject(j)
                    val p = g.getJSONArray("p")
                    val pts = ArrayList<Pt>()
                    var k = 0
                    while (k + 1 < p.length()) {
                        pts.add(Pt(p.getDouble(k).toFloat(), p.getDouble(k + 1).toFloat()))
                        k += 2
                    }
                    if (pts.isNotEmpty()) gestures.add(Gesture(g.getLong("g"), g.getLong("d"), pts))
                }
                out.add(
                    Recording(
                        o.getLong("id"), o.getString("name"), o.optLong("created", 0L),
                        o.optInt("w", 1080), o.optInt("h", 2400), gestures
                    )
                )
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun write(list: List<Recording>) {
        val arr = JSONArray()
        for (r in list) {
            val gs = JSONArray()
            for (g in r.gestures) {
                val p = JSONArray()
                for (pt in g.pts) {
                    p.put(pt.x.toDouble())
                    p.put(pt.y.toDouble())
                }
                gs.put(JSONObject().put("g", g.gapMs).put("d", g.durMs).put("p", p))
            }
            arr.put(
                JSONObject().put("id", r.id).put("name", r.name).put("created", r.created)
                    .put("w", r.w).put("h", r.h).put("gs", gs)
            )
        }
        sp.edit().putString("recs", arr.toString()).apply()
    }

    fun add(r: Recording) {
        val l = list()
        l.add(0, r)
        write(l)
    }

    fun delete(id: Long) {
        val l = list()
        l.removeAll { it.id == id }
        write(l)
    }

    fun rename(id: Long, name: String) {
        val l = list()
        for (r in l) if (r.id == id) r.name = name
        write(l)
    }

    fun selectedRec(): Recording? {
        val l = list()
        return l.firstOrNull { it.id == selected } ?: l.firstOrNull()
    }
}
